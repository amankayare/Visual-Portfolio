import { ReactNode } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft, Calendar, Clock, User, Share2, BookOpen, ExternalLink, TrendingUp, Tag, Moon, Sun } from 'lucide-react';
import { useTheme } from '@/hooks/use-theme';

interface BlogAuthor {
  id: number;
  name: string;
  email: string;
  avatar?: string;
}

interface BlogTag {
  id: number;
  name: string;
}

interface BlogLayoutProps {
  // Blog post metadata
  title: string;
  excerpt?: string;
  coverImage?: string;
  date: string;
  readingTime?: number;
  featured?: boolean;
  author?: BlogAuthor;
  tags?: BlogTag[];
  
  // Content
  children: ReactNode;
  
  // Navigation
  backTo?: string;
  showShareButton?: boolean;
  
  // Loading and error states
  isLoading?: boolean;
  error?: string;

  // Sidebar content
  relatedPosts?: Array<{
    id: number;
    title: string;
    readingTime?: number;
  }>;
  tableOfContents?: Array<{
    id: string;
    title: string;
    level: number;
  }>;
  showAds?: boolean;
}

export default function BlogLayout({
  title,
  excerpt,
  coverImage,
  date,
  readingTime,
  featured = false,
  author,
  tags = [],
  children,
  backTo = '/#blog',
  showShareButton = true,
  isLoading = false,
  error,
  relatedPosts = [],
  tableOfContents = [],
  showAds = true
}: BlogLayoutProps) {
  const [, setLocation] = useLocation();
  const { theme, setTheme } = useTheme();

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <BlogLayoutSkeleton />
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <BlogLayoutError error={error} backTo={backTo} />
      </div>
    );
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title,
        text: excerpt,
        url: window.location.href,
      });
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen hero-squares">
      {/* Fixed Header */}
      <header className="border-b border-border/40 bg-background/80 backdrop-blur-xl supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50 shadow-sm">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex h-16 items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => setLocation(backTo)} className="hover:bg-muted/50">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Blog
          </Button>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-primary" />
              <span className="font-semibold text-primary">Blog</span>
            </div>
            
            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleTheme}
              className="h-9 w-9 p-0 hover:bg-muted/50"
            >
              {theme === 'dark' ? (
                <Sun className="h-4 w-4" />
              ) : (
                <Moon className="h-4 w-4" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content with Sidebars */}
      <main className="container py-8 max-w-8xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
          {/* Left Sidebar */}
          <aside className="lg:col-span-2 order-3 lg:order-1">
            <div className="sticky top-24 space-y-6">
              <BlogSidebar 
                side="left" 
                tableOfContents={tableOfContents}
                showAds={showAds}
              />
            </div>
          </aside>

          {/* Main Blog Content */}
          <article className="lg:col-span-8 order-1 lg:order-2">
            <div className="space-y-8 bg-background/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6 lg:p-8 shadow-xl max-w-6xl mx-auto">
              {/* Hero Section */}
              <BlogHero
                title={title}
                excerpt={excerpt}
                featured={featured}
                author={author}
                date={date}
                readingTime={readingTime}
                tags={tags}
                onShare={showShareButton ? handleShare : undefined}
              />

              <Separator className="bg-gradient-to-r from-transparent via-border to-transparent" />

              {/* Cover Image */}
              {coverImage && (
                <BlogCoverImage src={coverImage} alt={title} />
              )}

              {/* Dynamic Content Area */}
              <div className="blog-content prose prose-lg prose-gray dark:prose-invert max-w-none px-4">
                {children}
              </div>
            </div>
          </article>

          {/* Right Sidebar */}
          <aside className="lg:col-span-2 order-2 lg:order-3">
            <div className="sticky top-24 space-y-6">
              <BlogSidebar 
                side="right" 
                relatedPosts={relatedPosts}
                showAds={showAds}
              />
            </div>
          </aside>
        </div>

        {/* Footer Navigation */}
        <div className="mt-12">
          <BlogFooter backTo={backTo} />
        </div>
      </main>
    </div>
  );
}

// Hero Section Component
interface BlogHeroProps {
  title: string;
  excerpt?: string;
  featured: boolean;
  author?: BlogAuthor;
  date: string;
  readingTime?: number;
  tags: BlogTag[];
  onShare?: () => void;
}

function BlogHero({ title, excerpt, featured, author, date, readingTime, tags, onShare }: BlogHeroProps) {
  return (
    <header className="space-y-6">
      {/* Featured Badge */}
      {featured && (
        <Badge variant="secondary" className="mb-4 bg-gradient-to-r from-yellow-400/20 to-orange-400/20 text-yellow-700 dark:text-yellow-300 border-yellow-400/30">
          ⭐ Featured Post
        </Badge>
      )}
      
      {/* Title and Actions */}
      <div className="flex flex-col gap-4">
        <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
          <h1 className="text-3xl lg:text-4xl xl:text-5xl font-bold leading-tight flex-1">
            {title}
          </h1>
          
          {onShare && (
            <Button variant="outline" size="sm" onClick={onShare} className="self-start hover:bg-primary hover:text-primary-foreground transition-all duration-200 hover:scale-105">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
          )}
        </div>
        
        {/* Excerpt */}
        {excerpt && (
          <p className="text-lg lg:text-xl text-muted-foreground leading-relaxed">
            {excerpt}
          </p>
        )}
      </div>

      {/* Meta Information */}
      <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
        {author && (
          <div className="flex items-center gap-2">
            {author.avatar ? (
              <img 
                src={author.avatar} 
                alt={author.name}
                className="w-6 h-6 rounded-full"
              />
            ) : (
              <User className="w-4 h-4" />
            )}
            <span className="font-medium">{author.name}</span>
          </div>
        )}
        
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          <span>{new Date(date).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}</span>
        </div>
        
        {readingTime && (
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            <span>{readingTime} min read</span>
          </div>
        )}
      </div>

      {/* Tags */}
      {tags.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {tags.map((tag) => (
            <Badge key={tag.id} variant="outline" className="hover:bg-primary hover:text-primary-foreground transition-all duration-200 cursor-pointer hover:scale-105 border-primary/30">
              #{tag.name}
            </Badge>
          ))}
        </div>
      )}
    </header>
  );
}

// Cover Image Component
interface BlogCoverImageProps {
  src: string;
  alt: string;
}

function BlogCoverImage({ src, alt }: BlogCoverImageProps) {
  return (
    <div className="relative aspect-video overflow-hidden rounded-lg border bg-muted">
      <img 
        src={src} 
        alt={alt}
        className="object-cover w-full h-full transition-transform hover:scale-105"
        loading="lazy"
      />
    </div>
  );
}

// Footer Component
interface BlogFooterProps {
  backTo: string;
}

function BlogFooter({ backTo }: BlogFooterProps) {
  const [, setLocation] = useLocation();
  
  return (
    <footer className="mt-12 pt-8 border-t border-border/40">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <Button onClick={() => setLocation(backTo)} variant="outline">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to All Posts
        </Button>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span>© 2025 Portfolio Blog</span>
          <Separator orientation="vertical" className="h-4" />
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="hover:text-foreground transition-colors"
          >
            Back to top ↑
          </button>
        </div>
      </div>
    </footer>
  );
}

// Loading Skeleton
function BlogLayoutSkeleton() {
  return (
    <>
      {/* Header Skeleton */}
      <header className="border-b border-border/40 h-16 bg-background">
        <div className="container flex h-16 items-center">
          <div className="h-8 w-24 bg-muted animate-pulse rounded" />
        </div>
      </header>

      {/* Content Skeleton */}
      <main className="container py-8 max-w-4xl">
        <div className="space-y-8">
          {/* Title skeleton */}
          <div className="space-y-4">
            <div className="h-12 bg-muted animate-pulse rounded w-3/4" />
            <div className="h-6 bg-muted animate-pulse rounded w-full" />
            <div className="h-6 bg-muted animate-pulse rounded w-2/3" />
          </div>
          
          {/* Meta skeleton */}
          <div className="flex gap-4">
            <div className="h-4 w-20 bg-muted animate-pulse rounded" />
            <div className="h-4 w-24 bg-muted animate-pulse rounded" />
            <div className="h-4 w-16 bg-muted animate-pulse rounded" />
          </div>
          
          {/* Image skeleton */}
          <div className="aspect-video bg-muted animate-pulse rounded-lg" />
          
          {/* Content skeleton */}
          <div className="space-y-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-4 bg-muted animate-pulse rounded w-full" />
            ))}
          </div>
        </div>
      </main>
    </>
  );
}

// Error Component
interface BlogLayoutErrorProps {
  error: string;
  backTo: string;
}

function BlogLayoutError({ error, backTo }: BlogLayoutErrorProps) {
  const [, setLocation] = useLocation();
  
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center max-w-md">
        <div className="text-6xl mb-4">📝</div>
        <h1 className="text-2xl font-bold mb-4">Blog Post Not Found</h1>
        <p className="text-muted-foreground mb-6">
          {error || "The blog post you're looking for doesn't exist or has been removed."}
        </p>
        <Button onClick={() => setLocation(backTo)}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Blog
        </Button>
      </div>
    </div>
  );
}

// Blog Sidebar Component
interface BlogSidebarProps {
  side: 'left' | 'right';
  tableOfContents?: { id: string; title: string; level: number; }[];
  relatedPosts?: { id: number; title: string; readingTime?: number; }[];
  showAds?: boolean;
}

function BlogSidebar({ 
  side, 
  tableOfContents = [], 
  relatedPosts = [], 
  showAds = true 
}: BlogSidebarProps) {
  if (side === 'left') {
    return (
      <div className="space-y-6">
        {/* Table of Contents */}
        {tableOfContents && tableOfContents.length > 0 && (
          <Card className="bg-background/60 backdrop-blur-sm border-border/50 shadow-lg hover:shadow-xl transition-all duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-semibold flex items-center gap-2 text-foreground/90">
                <BookOpen className="w-4 h-4 text-primary" />
                Contents
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <nav className="space-y-2">
                {tableOfContents.map((item) => (
                  <a 
                    key={item.id}
                    href={`#${item.id}`} 
                    className={`block text-sm text-muted-foreground hover:text-primary transition-colors py-2 px-2 rounded-md hover:bg-muted/50 ${
                      item.level > 1 ? 'ml-4 border-l-2 border-muted pl-4' : ''
                    }`}
                  >
                    {item.title}
                  </a>
                ))}
              </nav>
            </CardContent>
          </Card>
        )}

        {/* Quick Links */}
        <Card className="bg-background/60 backdrop-blur-sm border-border/50 shadow-lg hover:shadow-xl transition-all duration-300">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2 text-foreground/90">
              <ExternalLink className="w-4 h-4 text-primary" />
              Quick Links
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2">
              <a 
                href="#" 
                className="block text-sm text-primary hover:text-primary/80 transition-colors py-2 px-2 rounded-md hover:bg-primary/10"
              >
                GitHub Repository
              </a>
              <a 
                href="#" 
                className="block text-sm text-primary hover:text-primary/80 transition-colors py-2 px-2 rounded-md hover:bg-primary/10"
              >
                Live Demo
              </a>
              <a 
                href="#" 
                className="block text-sm text-primary hover:text-primary/80 transition-colors py-2 px-2 rounded-md hover:bg-primary/10"
              >
                Documentation
              </a>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Right sidebar
  return (
    <div className="space-y-6">
      {/* Related Posts */}
      {relatedPosts && relatedPosts.length > 0 && (
        <Card className="bg-background/60 backdrop-blur-sm border-border/50 shadow-lg hover:shadow-xl transition-all duration-300">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold flex items-center gap-2 text-foreground/90">
              <TrendingUp className="w-4 h-4 text-primary" />
              Related Posts
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              {relatedPosts.slice(0, 3).map((post, index) => (
                <div key={post.id}>
                  <div className="group cursor-pointer p-2 rounded-md hover:bg-muted/50 transition-colors">
                    <h4 className="text-sm font-medium group-hover:text-primary transition-colors line-clamp-2">
                      {post.title}
                    </h4>
                    {post.readingTime && (
                      <p className="text-xs text-muted-foreground mt-1">{post.readingTime} min read</p>
                    )}
                  </div>
                  {index < relatedPosts.slice(0, 3).length - 1 && <Separator className="bg-gradient-to-r from-transparent via-border to-transparent" />}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Popular Tags */}
      <Card className="bg-background/60 backdrop-blur-sm border-border/50 shadow-lg hover:shadow-xl transition-all duration-300">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2 text-foreground/90">
            <Tag className="w-4 h-4 text-primary" />
            Popular Tags
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary" className="text-xs cursor-pointer hover:bg-primary hover:text-primary-foreground transition-all duration-200 hover:scale-105">
              React
            </Badge>
            <Badge variant="secondary" className="text-xs cursor-pointer hover:bg-primary hover:text-primary-foreground transition-all duration-200 hover:scale-105">
              Flask
            </Badge>
            <Badge variant="secondary" className="text-xs cursor-pointer hover:bg-primary hover:text-primary-foreground transition-all duration-200 hover:scale-105">
              TypeScript
            </Badge>
            <Badge variant="secondary" className="text-xs cursor-pointer hover:bg-primary hover:text-primary-foreground transition-all duration-200 hover:scale-105">
              Web Dev
            </Badge>
            <Badge variant="secondary" className="text-xs cursor-pointer hover:bg-primary hover:text-primary-foreground transition-all duration-200 hover:scale-105">
              Tutorial
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Advertisement Placeholder */}
      {showAds && (
        <Card className="bg-gradient-to-br from-muted/20 to-muted/40 border-dashed border-2 border-muted-foreground/30 hover:border-muted-foreground/50 transition-all duration-300">
          <CardContent className="p-6 text-center">
            <div className="text-muted-foreground text-sm">
              <div className="w-full h-32 bg-gradient-to-br from-muted/50 to-muted/70 rounded-xl flex items-center justify-center mb-3 border border-muted-foreground/20">
                <span className="text-xs font-medium">Advertisement</span>
              </div>
              <p className="text-xs font-medium">Sponsored content will appear here</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
