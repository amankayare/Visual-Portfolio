import { cn } from '@/lib/utils';

// Blog content styling hook
export const useBlogContentStyles = () => {
  return {
    container: "blog-content min-h-[400px]",
    prose: cn(
      "prose prose-lg dark:prose-invert max-w-none",
      // Headings
      "prose-headings:scroll-m-20 prose-headings:font-semibold prose-headings:text-foreground",
      "prose-h1:text-3xl prose-h1:md:text-4xl prose-h1:border-b prose-h1:border-border/30 prose-h1:pb-2 prose-h1:mb-4",
      "prose-h2:text-2xl prose-h2:md:text-3xl prose-h2:border-b prose-h2:border-border/30 prose-h2:pb-2 prose-h2:mb-4",
      "prose-h3:text-xl prose-h3:md:text-2xl prose-h3:border-b prose-h3:border-border/30 prose-h3:pb-2 prose-h3:mb-4",
      "prose-h4:text-lg prose-h4:md:text-xl",
      // Paragraphs
      "prose-p:leading-relaxed prose-p:mb-4 prose-p:text-foreground/90",
      // Links
      "prose-a:text-primary prose-a:no-underline prose-a:underline-offset-4 prose-a:decoration-2",
      "hover:prose-a:underline hover:prose-a:text-primary/80 prose-a:font-medium prose-a:transition-colors",
      // Blockquotes
      "prose-blockquote:border-l-4 prose-blockquote:border-primary prose-blockquote:bg-muted/50", 
      "prose-blockquote:p-4 prose-blockquote:rounded-r-lg prose-blockquote:italic prose-blockquote:text-muted-foreground",
      // Code
      "prose-code:bg-muted prose-code:text-foreground prose-code:px-2 prose-code:py-1", 
      "prose-code:rounded prose-code:text-sm prose-code:font-mono prose-code:border prose-code:border-border/50",
      // Pre blocks
      "prose-pre:bg-muted prose-pre:border prose-pre:border-border prose-pre:rounded-lg", 
      "prose-pre:p-4 prose-pre:overflow-x-auto prose-pre:text-sm prose-pre:font-mono",
      // Lists
      "prose-ul:list-disc prose-ul:pl-6 prose-ul:my-4 prose-ol:list-decimal prose-ol:pl-6 prose-ol:my-4",
      "prose-li:marker:text-muted-foreground prose-li:mb-2 prose-li:text-foreground/90",
      // Strong and emphasis
      "prose-strong:text-foreground prose-strong:font-semibold",
      "prose-em:text-muted-foreground prose-em:italic",
      // Images
      "prose-img:rounded-lg prose-img:border prose-img:border-border prose-img:shadow-sm prose-img:mx-auto",
      // HR
      "prose-hr:border-border prose-hr:my-8",
      // Tables
      "prose-table:border-collapse prose-table:border prose-table:border-border prose-table:rounded-lg prose-table:overflow-hidden prose-table:my-6",
      "prose-th:border prose-th:border-border prose-th:bg-muted prose-th:p-3 prose-th:font-semibold prose-th:text-foreground",
      "prose-td:border prose-td:border-border prose-td:p-3 prose-td:border-b prose-td:border-border/50 prose-td:text-foreground/90"
    )
  };
};

// Blog layout responsive classes
export const blogLayoutClasses = {
  header: "border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50",
  container: "container py-8 max-w-4xl",
  article: "space-y-8",
  hero: "space-y-6",
  title: "text-4xl md:text-5xl font-bold leading-tight",
  excerpt: "text-xl text-muted-foreground leading-relaxed",
  meta: "flex flex-wrap items-center gap-4 text-sm text-muted-foreground",
  tags: "flex flex-wrap gap-2",
  coverImage: "relative aspect-video overflow-hidden rounded-lg border bg-muted",
  footer: "mt-12 pt-8 border-t border-border/40",
  footerContent: "flex flex-col sm:flex-row items-center justify-between gap-4"
};
