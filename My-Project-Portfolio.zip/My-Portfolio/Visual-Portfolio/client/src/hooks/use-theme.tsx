import { useTheme as useThemeOriginal } from "@/components/ui/theme-provider"

export const useTheme = useThemeOriginal
