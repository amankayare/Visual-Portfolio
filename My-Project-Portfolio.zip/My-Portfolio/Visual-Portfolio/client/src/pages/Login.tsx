import { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { Home } from 'lucide-react';

interface LoginData {
  username: string;
  password: string;
}

interface LoginResponse {
  access_token: string;
  user: {
    id: number;
    username: string;
    email: string;
    is_admin: boolean;
  };
  message: string;
}

export default function Login() {
  const [formData, setFormData] = useState<LoginData>({ username: '', password: '' });
  const [error, setError] = useState('');
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Check for auth error message on component mount
  useEffect(() => {
    const authError = localStorage.getItem('authError');
    if (authError) {
      setError(authError);
      localStorage.removeItem('authError'); // Clear the message after displaying
    }
  }, []);

  // Visual Studio Icon SVG
  const VSIcon = () => (
    <svg viewBox="0 0 256 256" className="w-6 h-6">
      <defs>
        <linearGradient id="vsGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0065A9" />
          <stop offset="100%" stopColor="#007ACC" />
        </linearGradient>
      </defs>
      <path
        d="M181.534 254.252a15.934 15.934 0 0 0 11.67-.886l46.021-23.85c4.345-2.254 7.775-7.775 7.775-13.42V39.904c0-5.645-3.43-11.166-7.775-13.42L193.204 2.634a15.939 15.939 0 0 0-18.61 2.478L81.844 92.31 31.94 53.088a10.655 10.655 0 0 0-13.01.56L5.716 64.265c-3.805 3.492-3.805 9.448 0 12.94l42.537 39.652L5.716 156.51c-3.805 3.492-3.805 9.448 0 12.94l13.214 10.617a10.655 10.655 0 0 0 13.01.56l49.904-39.222 92.75 87.198a15.939 15.939 0 0 0 6.94 1.649z"
        fill="url(#vsGradient)"
      />
    </svg>
  );

  const loginMutation = useMutation({
    mutationFn: async (data: LoginData): Promise<LoginResponse> => {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Login failed');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      localStorage.setItem('token', data.access_token);
      localStorage.setItem('user', JSON.stringify(data.user));
      localStorage.removeItem('authError'); // Clear any previous auth errors
      toast({
        title: 'Success',
        description: 'Successfully logged in!',
      });
      
      // Log user info for debugging
      console.log('Login successful. User data:', data.user);
      console.log('Is admin:', data.user.is_admin);
      
      // Check for return URL first
      const returnUrl = localStorage.getItem('returnUrl');
      if (returnUrl) {
        localStorage.removeItem('returnUrl');
        console.log('Redirecting to return URL:', returnUrl);
        setLocation(returnUrl);
        return;
      }
      
      // Default redirect logic based on user role
      if (data.user.is_admin) {
        console.log('Redirecting admin to admin panel');
        setLocation('/admin');
      } else {
        console.log('Redirecting non-admin user to blog home');
        setLocation('/blogs');
      }
    },
    onError: (error: Error) => {
      setError(error.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    loginMutation.mutate(formData);
  };

  return (
    <div className="h-screen flex flex-col bg-background text-foreground font-vs relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Gradient Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50/70 via-white to-purple-50/50 dark:from-gray-900 dark:via-gray-800 dark:to-blue-900/20"></div>
        
        {/* Floating Geometric Shapes with Enhanced Animations */}
        <div className="absolute top-10 left-10 w-64 h-64 bg-gradient-to-r from-blue-400/20 to-purple-400/20 dark:from-blue-500/20 dark:to-purple-500/20 rounded-full blur-3xl animate-pulse animate-float"></div>
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-gradient-to-r from-orange-400/20 to-red-400/20 dark:from-orange-500/20 dark:to-red-500/20 rounded-full blur-3xl animate-pulse delay-1000 animate-float"></div>
        <div className="absolute top-1/2 left-1/3 w-48 h-48 bg-gradient-to-r from-green-400/20 to-teal-400/20 dark:from-green-500/20 dark:to-teal-500/20 rounded-full blur-3xl animate-pulse delay-500 animate-float"></div>
        
        {/* Enhanced Floating Particles */}
        <div className="absolute inset-0">
          {/* Animated Dots - More visible in light theme */}
          <div className="absolute top-1/4 left-1/4 w-3 h-3 bg-blue-500/50 dark:bg-blue-500/30 rounded-full animate-bounce animate-float delay-100"></div>
          <div className="absolute top-1/3 right-1/4 w-4 h-4 bg-purple-500/50 dark:bg-purple-500/30 rounded-full animate-bounce animate-float delay-300"></div>
          <div className="absolute bottom-1/4 left-1/3 w-3 h-3 bg-green-500/50 dark:bg-green-500/30 rounded-full animate-bounce animate-float delay-500"></div>
          <div className="absolute top-3/4 right-1/3 w-3 h-3 bg-orange-500/50 dark:bg-orange-500/30 rounded-full animate-bounce animate-float delay-700"></div>
          <div className="absolute top-1/2 left-1/5 w-2 h-2 bg-red-500/60 dark:bg-red-500/40 rounded-full animate-ping animate-float delay-200"></div>
          <div className="absolute bottom-1/3 right-1/5 w-2 h-2 bg-blue-500/60 dark:bg-blue-500/40 rounded-full animate-ping animate-float delay-600"></div>
          
          {/* Enhanced Floating Elements with Custom Animation */}
          <div className="absolute top-20 right-20 w-10 h-10 border-2 border-blue-400/40 dark:border-blue-600/30 rounded-full animate-spin-slow animate-float"></div>
          <div className="absolute bottom-20 left-20 w-8 h-8 border-2 border-purple-400/40 dark:border-purple-600/30 rounded-full animate-spin-slow delay-1000 animate-float"></div>
          <div className="absolute top-1/2 right-1/6 w-6 h-6 border-2 border-green-400/40 dark:border-green-600/30 rounded-full animate-spin-slow delay-500 animate-float"></div>
          
          {/* Enhanced Moving Gradient Lines */}
          <div className="absolute top-0 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-blue-500/40 dark:via-blue-500/20 to-transparent animate-slide-x"></div>
          <div className="absolute top-1/3 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-purple-500/40 dark:via-purple-500/20 to-transparent animate-slide-x delay-2000"></div>
          <div className="absolute top-2/3 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-green-500/40 dark:via-green-500/20 to-transparent animate-slide-x delay-4000"></div>
          
          {/* Additional floating elements for more movement */}
          <div className="absolute top-10 left-1/2 w-5 h-5 bg-gradient-to-r from-blue-300/30 to-purple-300/30 dark:from-blue-500/20 dark:to-purple-500/20 rounded-full animate-bounce-slow animate-float delay-800"></div>
          <div className="absolute bottom-32 right-1/4 w-4 h-4 bg-gradient-to-r from-orange-300/30 to-red-300/30 dark:from-orange-500/20 dark:to-red-500/20 rounded-full animate-bounce-slow animate-float delay-1200"></div>
        </div>
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 bg-grid-pattern opacity-[0.02] dark:opacity-[0.05]"></div>
        
        {/* Subtle Lines */}
        <div className="absolute inset-0">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
                <path d="M 60 0 L 0 0 0 60" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-gray-200/20 dark:text-gray-700/30"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>
        
        {/* Animated Background Waves */}
        <div className="absolute bottom-0 left-0 w-full overflow-hidden">
          <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="relative block w-full h-16">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" 
                  className="fill-blue-100/30 dark:fill-blue-900/20 animate-wave"></path>
          </svg>
        </div>
      </div>
      {/* Header */}
      <div className="relative z-10 flex items-center justify-between p-4 bg-background/80 backdrop-blur-xl border-b border-border/40">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3 cursor-pointer transition-transform hover:scale-105" onClick={() => setLocation("/blogs")}>
            <svg className="w-32 h-8 sm:w-40 sm:h-10 md:w-44 md:h-11 lg:w-48 lg:h-12" viewBox="0 0 180 48" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="2" y="8" width="32" height="32" rx="6" fill="#3490dc" />
              <path d="M10 16h16M10 24h16M10 32h16" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
              <path d="M6 12l4-4 4 4" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
              <text x="40" y="26" fontFamily="Segoe UI, Arial, sans-serif" fontSize="22" fontWeight="bold" fill="#2563eb">Blog</text>
              <text x="90" y="26" fontFamily="Segoe UI, Arial, sans-serif" fontSize="22" fontWeight="bold" fill="#f97316">Master</text>
              <text x="40" y="44" fontFamily="Segoe UI, Arial, sans-serif" fontSize="16" fontWeight="bold" fill="#22c55e">Insights</text>
            </svg>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <ThemeToggle 
            variant="ghost"
            className="hover:bg-accent/50 rounded-lg transition-all duration-200 backdrop-blur-sm"
            showTooltip={true}
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-card/90 backdrop-blur-xl border-border/40 shadow-2xl shadow-black/5 dark:shadow-black/20">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-primary via-blue-600 to-purple-600 bg-clip-text text-transparent">
            Hi! Welcome
          </CardTitle>
          <CardDescription className="text-muted-foreground/80">
            Sign in to your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="username">Username or Email</Label>
              <Input
                id="username"
                type="text"
                value={formData.username}
                onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Enter your username or email"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                placeholder="Enter your password"
                required
              />
            </div>

            <Button 
              type="submit" 
              className="w-full text-white" 
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? 'Signing in...' : 'Sign In'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="justify-center">
          <p className="text-sm text-muted-foreground">
            Don't have an account?{' '}
            <Link href="/register" className="text-primary hover:underline">
              Sign up
            </Link>
          </p>
        </CardFooter>
      </Card>
      </div>
    </div>
  );
}