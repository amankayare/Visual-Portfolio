import { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { ArrowLeft } from 'lucide-react';

interface LoginData {
  username: string;
  password: string;
}

interface LoginResponse {
  access_token: string;
  user: {
    id: number;
    username: string;
    email: string;
    is_admin: boolean;
  };
  message: string;
}

export default function Login() {
  const [formData, setFormData] = useState<LoginData>({ username: '', password: '' });
  const [error, setError] = useState('');
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Check for auth error message on component mount
  useEffect(() => {
    const authError = localStorage.getItem('authError');
    if (authError) {
      setError(authError);
      localStorage.removeItem('authError'); // Clear the message after displaying
    }
  }, []);

  // Visual Studio Icon SVG
  const VSIcon = () => (
    <svg viewBox="0 0 256 256" className="w-6 h-6">
      <defs>
        <linearGradient id="vsGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#0065A9" />
          <stop offset="100%" stopColor="#007ACC" />
        </linearGradient>
      </defs>
      <path
        d="M181.534 254.252a15.934 15.934 0 0 0 11.67-.886l46.021-23.85c4.345-2.254 7.775-7.775 7.775-13.42V39.904c0-5.645-3.43-11.166-7.775-13.42L193.204 2.634a15.939 15.939 0 0 0-18.61 2.478L81.844 92.31 31.94 53.088a10.655 10.655 0 0 0-13.01.56L5.716 64.265c-3.805 3.492-3.805 9.448 0 12.94l42.537 39.652L5.716 156.51c-3.805 3.492-3.805 9.448 0 12.94l13.214 10.617a10.655 10.655 0 0 0 13.01.56l49.904-39.222 92.75 87.198a15.939 15.939 0 0 0 6.94 1.649z"
        fill="url(#vsGradient)"
      />
    </svg>
  );

  const loginMutation = useMutation({
    mutationFn: async (data: LoginData): Promise<LoginResponse> => {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Login failed');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      localStorage.setItem('token', data.access_token);
      localStorage.setItem('user', JSON.stringify(data.user));
      localStorage.removeItem('authError'); // Clear any previous auth errors
      toast({
        title: 'Success',
        description: 'Successfully logged in!',
      });
      
      // Log user info for debugging
      console.log('Login successful. User data:', data.user);
      console.log('Is admin:', data.user.is_admin);
      
      // Check for return URL first
      const returnUrl = localStorage.getItem('returnUrl');
      if (returnUrl) {
        localStorage.removeItem('returnUrl');
        console.log('Redirecting to return URL:', returnUrl);
        setLocation(returnUrl);
        return;
      }
      
      // Default redirect logic based on user role
      if (data.user.is_admin) {
        console.log('Redirecting admin to admin panel');
        setLocation('/admin');
      } else {
        console.log('Redirecting non-admin user to blog home');
        setLocation('/blogs');
      }
    },
    onError: (error: Error) => {
      setError(error.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    loginMutation.mutate(formData);
  };

  return (
    <div className="h-screen flex flex-col bg-background text-foreground font-vs">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-[hsl(var(--vs-header-bg))] border-b border-border">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <VSIcon />
            <span className="text-2xl font-savate font-bold text-foreground hidden sm:block">
              Aman Kayare
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <ThemeToggle 
            variant="ghost"
            className="hover:bg-[hsl(var(--vs-sidebar-hover))] rounded-lg transition-all duration-200"
            showTooltip={true}
          />
          <Button
            variant="outline"
            size="sm"
            onClick={() => setLocation("/")}
            className="bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-gray-900 dark:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-700 px-3 py-1 rounded-lg text-sm font-medium"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Welcome Back</CardTitle>
          <CardDescription>Sign in to your account</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="username">Username or Email</Label>
              <Input
                id="username"
                type="text"
                value={formData.username}
                onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Enter your username or email"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={formData.password}
                onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                placeholder="Enter your password"
                required
              />
            </div>

            <Button 
              type="submit" 
              className="w-full text-white" 
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? 'Signing in...' : 'Sign In'}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="justify-center">
          <p className="text-sm text-muted-foreground">
            Don't have an account?{' '}
            <Link href="/register" className="text-primary hover:underline">
              Sign up
            </Link>
          </p>
        </CardFooter>
      </Card>
      </div>
    </div>
  );
}