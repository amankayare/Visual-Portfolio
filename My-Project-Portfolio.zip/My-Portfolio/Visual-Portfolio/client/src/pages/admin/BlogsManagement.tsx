import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { HtmlCodeEditor } from '@/components/ui/html-code-editor';
import { useToast } from '@/hooks/use-toast';
import { useSearchFilter } from '@/hooks/use-search-filter';
import { Plus, Edit, Trash2, Star, Search, X, Eye } from 'lucide-react';
import AdminLayout from '@/components/admin/AdminLayout';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { useDeleteConfirmation } from '@/hooks/useDeleteConfirmation';
import { apiGet, apiPost, apiPut, apiDelete } from '@/utils/api';
import ImageInput from '@/components/ui/ImageInput';

interface Blog {
  id: number;
  title: string;
  excerpt?: string;
  content: string;
  cover_image?: string;
  date: string;
  reading_time?: number;
  featured: boolean;
  author_id?: number;
  tags: Array<{ id: number; name: string }>;
}

interface BlogFormData {
  title: string;
  excerpt: string;
  content: string;
  cover_image: string;
  reading_time: string;
  featured: boolean;
  tag_names: string;
}

export default function BlogsManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingBlog, setEditingBlog] = useState<Blog | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState<BlogFormData>({
    title: '',
    excerpt: '',
    content: '',
    cover_image: '',
    reading_time: '',
    featured: false,
    tag_names: ''
  });

  // Delete confirmation setup
  const deleteConfirmation = useDeleteConfirmation({
    onDelete: (id: number) => deleteMutation.mutate(id),
    itemName: (blog: Blog) => blog.title,
    itemType: 'blog post',
  });

  const { data: blogs, isLoading } = useQuery({
    queryKey: ['/api/blogs/admin'],
    queryFn: () => apiGet('/api/blogs/admin'),
  });

  // Filter blogs based on search query
  const filteredBlogs = useSearchFilter(
    blogs || [],
    searchQuery,
    ['title', 'excerpt', 'content'] as (keyof Blog)[],
    'tags' // This will search in the tags array for tag names
  );

  // Clear search function
  const clearSearch = () => setSearchQuery('');

  const createMutation = useMutation({
    mutationFn: async (data: BlogFormData) => {
      const payload = {
        ...data,
        reading_time: data.reading_time ? parseInt(data.reading_time) : null,
        tags: data.tag_names.split(',').map(t => t.trim()).filter(Boolean),
      };
      return apiPost('/api/blogs/', payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/blogs/admin'] });
      setIsCreateOpen(false);
      resetForm();
      toast({ title: 'Success', description: 'Blog created successfully.' });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: BlogFormData }) => {
      const payload = {
        ...data,
        reading_time: data.reading_time ? parseInt(data.reading_time) : null,
        tags: data.tag_names.split(',').map(t => t.trim()).filter(Boolean),
      };
      return apiPut(`/api/blogs/${id}`, payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/blogs/admin'] });
      setEditingBlog(null);
      resetForm();
      toast({ title: 'Success', description: 'Blog updated successfully.' });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiDelete(`/api/blogs/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/blogs/admin'] });
      toast({ title: 'Success', description: 'Blog deleted successfully.' });
    },
  });

  const resetForm = () => {
    setFormData({
      title: '',
      excerpt: '',
      content: '',
      cover_image: '',
      reading_time: '',
      featured: false,
      tag_names: ''
    });
  };

  const handleEdit = (blog: Blog) => {
    setFormData({
      title: blog.title,
      excerpt: blog.excerpt || '',
      content: blog.content,
      cover_image: blog.cover_image || '',
      reading_time: blog.reading_time?.toString() || '',
      featured: blog.featured,
      tag_names: blog.tags?.map(tag => tag.name).join(', ') || ''
    });
    setEditingBlog(blog);
  };

  const handleViewBlog = (blog: Blog) => {
    // Navigate to the blog post page
    setLocation(`/blog/${blog.id}`);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingBlog) {
      updateMutation.mutate({ id: editingBlog.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <AdminLayout title="Manage Blog Posts">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-10">
          {/* Enhanced Header Section */}
          <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-800 dark:via-gray-900 dark:to-gray-800 rounded-2xl p-8 border border-gray-200 dark:border-gray-700 shadow-sm">
            <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                    <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                    </svg>
                  </div>
                  <h1 className="text-3xl p-2 font-bold bg-gradient-to-r from-gray-900 to-gray-600 dark:from-white dark:to-gray-300 bg-clip-text text-transparent">
                    Blog Management
                  </h1>
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-base max-w-2xl leading-relaxed">
                  Create, edit, and manage your blog articles. Share your thoughts, tutorials, and insights with your audience.
                </p>
                
                {/* Search Bar */}
                <div className="relative max-w-md mt-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 dark:text-gray-500 w-4 h-4" />
                    <Input
                      type="text"
                      placeholder="Search blog posts..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 pr-10 h-10 bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent"
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={clearSearch}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                  {searchQuery && (
                    <div className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                      Found {filteredBlogs.length} of {blogs?.length || 0} posts
                    </div>
                  )}
                </div>
                
                <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400 mt-3">
                  <span className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    {blogs?.length || 0} Total Posts
                  </span>
                  <span className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                    {blogs?.filter(blog => blog.featured).length || 0} Featured
                  </span>
                </div>
              </div>
              <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                <DialogTrigger asChild>
                  <Button 
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 px-6 py-3 font-semibold rounded-xl border-0 w-full lg:w-auto transform hover:scale-105" 
                    onClick={() => { resetForm(); setEditingBlog(null); }}
                  >
                    <Plus className="w-5 h-5 mr-2" />
                    Create New Post
                  </Button>
                </DialogTrigger>
            <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto bg-white dark:bg-gray-900 border-0 shadow-2xl rounded-2xl">
              <DialogHeader className="pb-6 border-b border-gray-200 dark:border-gray-700">
                <DialogTitle className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                    <Plus className="w-4 h-4 text-white" />
                  </div>
                  {editingBlog ? 'Edit Blog Post' : 'Create New Blog Post'}
                </DialogTitle>
                <DialogDescription className="text-gray-600 dark:text-gray-300 text-base mt-2">
                  Fill out the form below to {editingBlog ? 'update' : 'create'} a blog post. All fields marked with * are required.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-6 pt-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="title" className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                      <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                      Title
                    </Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                      required
                      className="h-12 text-base border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-blue-500 dark:focus:border-blue-400 transition-colors bg-gray-50 dark:bg-gray-800"
                      placeholder="Enter an engaging title for your blog post"
                    />
                  </div>
                  <div className="space-y-3">
                    <Label htmlFor="reading_time" className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                      Reading Time (minutes)
                    </Label>
                    <Input
                      id="reading_time"
                      type="number"
                      value={formData.reading_time}
                      onChange={(e) => setFormData(prev => ({ ...prev, reading_time: e.target.value }))}
                      className="h-12 text-base border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-blue-500 dark:focus:border-blue-400 transition-colors bg-gray-50 dark:bg-gray-800"
                      placeholder="Estimated reading time"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="excerpt" className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                    Excerpt
                  </Label>
                  <Textarea
                    id="excerpt"
                    value={formData.excerpt}
                    onChange={(e) => setFormData(prev => ({ ...prev, excerpt: e.target.value }))}
                    rows={3}
                    placeholder="Brief description of the blog post that will appear in previews"
                    className="text-base border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-blue-500 dark:focus:border-blue-400 transition-colors bg-gray-50 dark:bg-gray-800 resize-none"
                  />
                </div>

                <div className="space-y-3">
                  <Label htmlFor="content" className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                    <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                    Content
                  </Label>
                  <div className="border-2 border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden bg-gray-50 dark:bg-gray-800">
                    <HtmlCodeEditor
                      value={formData.content}
                      onChange={(content) => setFormData(prev => ({ ...prev, content }))}
                      placeholder="Enter your HTML content here... Use any HTML tags and styling."
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <ImageInput
                      label="Cover Image"
                      currentUrl={formData.cover_image}
                      onUrlChange={(url) => setFormData(prev => ({ ...prev, cover_image: url }))}
                      onUploadSuccess={(url) => setFormData(prev => ({ ...prev, cover_image: url }))}
                      onDelete={() => setFormData(prev => ({ ...prev, cover_image: '' }))}
                      accept="image/*"
                      maxSize={5}
                      uploadType="cover"
                      placeholder="Enter cover image URL..."
                    />
                  </div>
                  <div className="space-y-3">
                    <Label htmlFor="tag_names" className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                      Tags (comma-separated)
                    </Label>
                    <Input
                      id="tag_names"
                      value={formData.tag_names}
                      onChange={(e) => setFormData(prev => ({ ...prev, tag_names: e.target.value }))}
                      placeholder="react, javascript, tutorial, web development"
                      className="h-12 text-base border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-blue-500 dark:focus:border-blue-400 transition-colors bg-gray-50 dark:bg-gray-800"
                    />
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="featured" className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                        <Star className="w-4 h-4 text-yellow-500" />
                        Featured Post
                      </Label>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Featured posts appear prominently on your blog</p>
                    </div>
                    <Switch
                      id="featured"
                      checked={formData.featured}
                      onCheckedChange={(checked) => setFormData(prev => ({ ...prev, featured: checked }))}
                      className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-blue-500 data-[state=checked]:to-purple-600"
                    />
                  </div>
                </div>

                <DialogFooter className="pt-6 border-t border-gray-200 dark:border-gray-700 gap-3">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setIsCreateOpen(false);
                      setEditingBlog(null);
                      resetForm();
                    }}
                    className="px-6 py-3 rounded-xl border-2 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createMutation.isPending || updateMutation.isPending} 
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-0"
                  >
                    {(createMutation.isPending || updateMutation.isPending) ? (
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        {editingBlog ? 'Updating...' : 'Creating...'}
                      </div>
                    ) : (
                      <>{editingBlog ? 'Update' : 'Create'} Blog Post</>
                    )}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Enhanced Loading State */}
        {isLoading ? (
          <div className="space-y-6">
            <div className="text-center py-12">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl mx-auto mb-4 flex items-center justify-center animate-pulse">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Loading your blog posts...</h3>
              <p className="text-gray-500 dark:text-gray-400">Please wait while we fetch your content</p>
            </div>
          </div>
        ) : blogs && blogs.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 rounded-2xl mx-auto mb-6 flex items-center justify-center">
              <svg className="w-10 h-10 text-gray-400 dark:text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.746 0 3.332.477 4.5 1.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">No blog posts yet</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">
              Start creating engaging content for your audience. Your first blog post is just a click away!
            </p>
            <Button 
              onClick={() => setIsCreateOpen(true)}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-0"
            >
              <Plus className="w-5 h-5 mr-2" />
              Create Your First Post
            </Button>
          </div>
        ) : filteredBlogs.length === 0 && searchQuery ? (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 rounded-2xl mx-auto mb-6 flex items-center justify-center">
              <Search className="w-10 h-10 text-gray-400 dark:text-gray-500" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">No posts found</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-6 max-w-md mx-auto">
              No blog posts match your search for "{searchQuery}". Try a different search term.
            </p>
            <Button 
              onClick={clearSearch}
              variant="outline"
              className="border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-800"
            >
              <X className="w-4 h-4 mr-2" />
              Clear Search
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 mt-8 max-w-7xl mx-auto">
            {filteredBlogs?.map((blog, index) => (
              <Card 
                key={blog.id} 
                className={`group hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-md w-full ${
                  blog.featured ? 'ring-2 ring-yellow-400 dark:ring-yellow-500' : ''
                }`}
                style={{
                  animationDelay: `${index * 100}ms`,
                  animation: 'fadeInUp 0.6s ease-out forwards'
                }}
              >
                <div className="relative">
                  {blog.cover_image && (
                    <div className="h-48 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 overflow-hidden">
                      <img 
                        src={blog.cover_image} 
                        alt={blog.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                        }}
                      />
                    </div>
                  )}
                  {blog.featured && (
                    <div className="absolute top-4 left-4">
                      <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1 shadow-lg">
                        <Star className="w-3 h-3 fill-current" />
                        Featured
                      </div>
                    </div>
                  )}
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleViewBlog(blog)}
                        title="View Blog Post"
                        className="bg-blue-500/90 hover:bg-blue-600 text-white backdrop-blur-sm border-0 shadow-lg rounded-xl"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="secondary" 
                        size="sm" 
                        onClick={() => handleEdit(blog)}
                        className="bg-white/90 dark:bg-gray-800/90 hover:bg-white dark:hover:bg-gray-800 backdrop-blur-sm border-0 shadow-lg rounded-xl"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="destructive" 
                        size="sm" 
                        onClick={() => deleteConfirmation.openConfirmDialog(blog)}
                        disabled={deleteMutation.isPending}
                        className="bg-red-500/90 hover:bg-red-600 backdrop-blur-sm border-0 shadow-lg rounded-xl"
                      >
                        {deleteMutation.isPending ? (
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
                
                <CardHeader className="p-6 pb-4">
                  <div className="space-y-4">
                    <CardTitle className="text-xl font-bold text-gray-900 dark:text-white line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors leading-tight">
                      {blog.title}
                    </CardTitle>
                    <div className="flex items-center gap-6 text-sm text-gray-500 dark:text-gray-400">
                      <div className="flex items-center gap-2">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        {new Date(blog.date).toLocaleDateString('en-US', { 
                          year: 'numeric', 
                          month: 'short', 
                          day: 'numeric' 
                        })}
                      </div>
                      {blog.reading_time && (
                        <div className="flex items-center gap-2">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                          {blog.reading_time} min read
                        </div>
                      )}
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="px-6 pb-6 space-y-5">
                  {blog.excerpt && (
                    <div className="mb-1">
                      <p className="text-gray-600 dark:text-gray-300 line-clamp-2 leading-relaxed text-base">
                        {blog.excerpt}
                      </p>
                    </div>
                  )}
                  
                  {blog.tags && blog.tags.length > 0 && (
                    <div className="space-y-3">
                      <div className="flex flex-wrap gap-2">
                        {blog.tags.slice(0, 4).map((tag) => (
                          <Badge 
                            key={tag.id} 
                            variant="secondary" 
                            className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/30 dark:to-purple-900/30 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-700 hover:from-blue-100 hover:to-purple-100 dark:hover:from-blue-900/50 dark:hover:to-purple-900/50 transition-colors rounded-full px-3 py-1.5 text-xs font-medium"
                          >
                            #{tag.name}
                          </Badge>
                        ))}
                        {blog.tags.length > 4 && (
                          <Badge variant="outline" className="rounded-full px-3 py-1.5 text-xs">
                            +{blog.tags.length - 4} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="flex justify-between items-center pt-4 mt-2 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full ${blog.featured ? 'bg-yellow-400' : 'bg-gray-400'}`}></div>
                      <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                        {blog.featured ? 'Featured Post' : 'Regular Post'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
                      <span>ID: {blog.id}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        </div>
      </div>

      {/* Enhanced Edit Dialog */}
      <Dialog open={!!editingBlog} onOpenChange={(open) => {
        if (!open) {
          setEditingBlog(null);
          resetForm();
        }
      }}>
        <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto bg-white dark:bg-gray-900 border-0 shadow-2xl rounded-2xl">
          <DialogHeader className="pb-6 border-b border-gray-200 dark:border-gray-700">
            <DialogTitle className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg flex items-center justify-center">
                <Edit className="w-4 h-4 text-white" />
              </div>
              Edit Blog Post
            </DialogTitle>
            <DialogDescription className="text-gray-600 dark:text-gray-300 text-base mt-2">
              Update the blog post information below. All fields marked with * are required.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6 pt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-3">
                <Label htmlFor="edit-title" className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                  <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                  Title
                </Label>
                <Input
                  id="edit-title"
                  value={formData.title}
                  onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                  required
                  className="h-12 text-base border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-orange-500 dark:focus:border-orange-400 transition-colors bg-gray-50 dark:bg-gray-800"
                  placeholder="Enter an engaging title for your blog post"
                />
              </div>
              <div className="space-y-3">
                <Label htmlFor="edit-reading_time" className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                  Reading Time (minutes)
                </Label>
                <Input
                  id="edit-reading_time"
                  type="number"
                  value={formData.reading_time}
                  onChange={(e) => setFormData(prev => ({ ...prev, reading_time: e.target.value }))}
                  className="h-12 text-base border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-orange-500 dark:focus:border-orange-400 transition-colors bg-gray-50 dark:bg-gray-800"
                  placeholder="Estimated reading time"
                />
              </div>
            </div>

            <div className="space-y-3">
              <Label htmlFor="edit-excerpt" className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                Excerpt
              </Label>
              <Textarea
                id="edit-excerpt"
                value={formData.excerpt}
                onChange={(e) => setFormData(prev => ({ ...prev, excerpt: e.target.value }))}
                rows={3}
                placeholder="Brief description of the blog post that will appear in previews"
                className="text-base border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-orange-500 dark:focus:border-orange-400 transition-colors bg-gray-50 dark:bg-gray-800 resize-none"
              />
            </div>

            <div className="space-y-3">
              <Label htmlFor="edit-content" className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                <span className="w-2 h-2 bg-red-500 rounded-full"></span>
                Content
              </Label>
              <div className="border-2 border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden bg-gray-50 dark:bg-gray-800">
                <HtmlCodeEditor
                  value={formData.content}
                  onChange={(content) => setFormData(prev => ({ ...prev, content }))}
                  placeholder="Enter your HTML content here... Use any HTML tags and styling."
                />
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-3">
                <ImageInput
                  label="Cover Image"
                  currentUrl={formData.cover_image}
                  onUrlChange={(url) => setFormData(prev => ({ ...prev, cover_image: url }))}
                  onUploadSuccess={(url) => setFormData(prev => ({ ...prev, cover_image: url }))}
                  onDelete={() => setFormData(prev => ({ ...prev, cover_image: '' }))}
                  accept="image/*"
                  maxSize={5}
                  uploadType="cover"
                  placeholder="Enter cover image URL..."
                />
              </div>
              <div className="space-y-3">
                <Label htmlFor="edit-tag_names" className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                  Tags (comma-separated)
                </Label>
                <Input
                  id="edit-tag_names"
                  value={formData.tag_names}
                  onChange={(e) => setFormData(prev => ({ ...prev, tag_names: e.target.value }))}
                  placeholder="react, javascript, tutorial, web development"
                  className="h-12 text-base border-2 border-gray-200 dark:border-gray-700 rounded-xl focus:border-orange-500 dark:focus:border-orange-400 transition-colors bg-gray-50 dark:bg-gray-800"
                />
              </div>
            </div>

            <div className="bg-gradient-to-r from-orange-50 to-red-50 dark:from-gray-800 dark:to-gray-800 rounded-xl p-4 border border-gray-200 dark:border-gray-700">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="edit-featured" className="text-sm font-semibold text-gray-700 dark:text-gray-300 flex items-center gap-2">
                    <Star className="w-4 h-4 text-yellow-500" />
                    Featured Post
                  </Label>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Featured posts appear prominently on your blog</p>
                </div>
                <Switch
                  id="edit-featured"
                  checked={formData.featured}
                  onCheckedChange={(checked) => setFormData(prev => ({ ...prev, featured: checked }))}
                  className="data-[state=checked]:bg-gradient-to-r data-[state=checked]:from-orange-500 data-[state=checked]:to-red-600"
                />
              </div>
            </div>

            <DialogFooter className="pt-6 border-t border-gray-200 dark:border-gray-700 gap-3">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => {
                  setEditingBlog(null);
                  resetForm();
                }}
                className="px-6 py-3 rounded-xl border-2 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={updateMutation.isPending} 
                className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-0"
              >
                {updateMutation.isPending ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Updating...
                  </div>
                ) : (
                  <>Update Blog Post</>
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
      </div>

      {/* Delete Confirmation Dialog */}
      <ConfirmDialog
        open={deleteConfirmation.confirmState.isOpen}
        onOpenChange={deleteConfirmation.closeConfirmDialog}
        title={deleteConfirmation.getTitle()}
        description={deleteConfirmation.getConfirmationText()}
        confirmText="Delete"
        cancelText="Cancel"
        variant="destructive"
        onConfirm={deleteConfirmation.confirmDelete}
        isLoading={deleteMutation.isPending}
      />
    </AdminLayout>
  );
}