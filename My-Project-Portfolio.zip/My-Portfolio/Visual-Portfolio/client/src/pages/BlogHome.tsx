import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Search, ExternalLink, Calendar, User, Clock, Eye, BookOpen, X, LogIn, UserPlus, LogOut, Settings, ChevronDown } from 'lucide-react';
import { useTheme } from '@/hooks/use-theme';
import { useToast } from '@/hooks/use-toast';

// Sidebar widgets can be imported or implemented here
// import BlogSidebar from '@/components/BlogSidebar';

interface Blog {
  id: number;
  title: string;
  excerpt?: string;
  content: string;
  cover_image?: string;
  date: string;
  reading_time?: number;
  featured: boolean;
  author?: { id: number; name: string; email?: string };
  tags?: Array<{ id: number; name: string }>;
  category?: { id: number; name: string };
}

interface Category {
  id: number;
  name: string;
}

export default function BlogHome() {
  const { theme, setTheme } = useTheme();
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);

  // Check authentication status
  useEffect(() => {
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');

    if (token && user) {
      try {
        setCurrentUser(JSON.parse(user));
      } catch (error) {
        console.error('Error parsing user data:', error);
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      }
    }
  }, []);

  // Handle URL parameters on component mount
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tagParam = urlParams.get('tag');
    if (tagParam) {
      setSelectedTag(tagParam.toLowerCase());
    }
  }, [location]);

  const { data: blogs = [], isLoading, error } = useQuery({
    queryKey: ['/api/blogs/', search],
    queryFn: async (): Promise<Blog[]> => {
      const response = await fetch('/api/blogs/');
      if (!response.ok) throw new Error('Failed to fetch blogs');
      return response.json();
    },
    staleTime: 5 * 60 * 1000,
  });
  // Fetch categories dynamically
  const { data: categories = [], isLoading: isCategoriesLoading, error: categoriesError } = useQuery({
    queryKey: ['/api/blog-categories'],
    queryFn: async (): Promise<Category[]> => {
      const response = await fetch('/api/blog-categories');
      if (!response.ok) throw new Error('Failed to fetch categories');
      return response.json();
    },
    staleTime: 10 * 60 * 1000,
  });

  const filteredBlogs = blogs.filter(
    (blog) => {
      // Search filter
      const matchesSearch = search === '' ||
        blog.title.toLowerCase().includes(search.toLowerCase()) ||
        (blog.excerpt && blog.excerpt.toLowerCase().includes(search.toLowerCase())) ||
        (blog.tags && blog.tags.some((tag) => tag.name.toLowerCase().includes(search.toLowerCase())));

      // Category filter
      const matchesCategory = selectedCategory === null ||
        (blog.category && blog.category.id === selectedCategory);

      // Tag filter
      const matchesTag = selectedTag === null ||
        (blog.tags && blog.tags.some((tag) => tag.name.toLowerCase() === selectedTag));

      return matchesSearch && matchesCategory && matchesTag;
    }
  );

  useEffect(() => {
    const cards = document.querySelectorAll('.blog-card-animate');
    cards.forEach((card, i) => {
      card.classList.add('opacity-0', 'translate-y-8');
      setTimeout(() => {
        card.classList.remove('opacity-0', 'translate-y-8');
        card.classList.add('opacity-100', 'translate-y-0', 'transition-all', 'duration-700');
      }, 100 + i * 120);
    });
  }, [filteredBlogs]);

  // Helper functions for filter management
  const clearAllFilters = () => {
    setSearch('');
    setSelectedCategory(null);
    setSelectedTag(null);
    // Update URL to remove tag parameter
    const url = new URL(window.location.href);
    url.searchParams.delete('tag');
    window.history.replaceState({}, '', url.toString());
  };

  const clearTagFilter = () => {
    setSelectedTag(null);
    const url = new URL(window.location.href);
    url.searchParams.delete('tag');
    window.history.replaceState({}, '', url.toString());
  };

  const hasActiveFilters = search !== '' || selectedCategory !== null || selectedTag !== null;

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setCurrentUser(null);
    toast({
      title: 'Logged Out',
      description: 'You have been successfully logged out.',
    });
  };

  return (
    <div className="hero-squares min-h-screen bg-gradient-to-br from-background/90 via-card/90 to-muted/80">
      {/* Header */}
      <header className="border-b border-border/40 bg-background/80 backdrop-blur-xl sticky top-0 z-50 shadow-lg">
        <div className="container mx-auto px-4 flex h-24 items-center justify-between">
          <div>
            <h1 className="text-5xl font-black text-gradient bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent tracking-tight drop-shadow-lg mb-2">
              <svg width="180" height="48" viewBox="0 0 180 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="2" y="8" width="32" height="32" rx="6" fill="#3490dc" />
                <path d="M10 16h16M10 24h16M10 32h16" stroke="#fff" stroke-width="2" stroke-linecap="round" />
                <path d="M6 12l4-4 4 4" stroke="#fff" stroke-width="2" stroke-linecap="round" />
                <text x="40" y="26" font-family="Segoe UI, Arial, sans-serif" font-size="22" font-weight="bold" fill="#2563eb">Blog</text>
                <text x="90" y="26" font-family="Segoe UI, Arial, sans-serif" font-size="22" font-weight="bold" fill="#f97316">Master</text>
                <text x="40" y="44" font-family="Segoe UI, Arial, sans-serif" font-size="16" font-weight="bold" fill="#22c55e">Insights</text>
              </svg>
            </h1>
          </div>
          <div className="flex items-center gap-6">
            <div className="relative w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-5 h-5" />
              <Input
                placeholder="Search articles..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10 pr-4 py-3 rounded-xl shadow focus:ring-2 focus:ring-primary/40 bg-card/80 border border-border"
              />
            </div>

            {/* Authentication Buttons */}
            {currentUser ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="flex items-center gap-2 px-3 py-2 h-auto rounded-lg hover:bg-accent transition-colors border"
                  >
                    <User className="w-4 h-4 text-primary" />
                    <span className="text-sm font-medium text-foreground">
                      {currentUser.username}
                    </span>
                    {currentUser.is_admin && (
                      <Badge variant="secondary" className="text-xs px-2 py-0.5 ml-1">
                        Admin
                      </Badge>
                    )}
                    <ChevronDown className="w-4 h-4 ml-2" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" side="bottom" className="w-48 min-w-[12rem] bg-popover border shadow-md">
                  <DropdownMenuItem
                    onClick={() => setLocation('/profile')}
                    className="cursor-pointer hover:bg-accent"
                  >
                    <Settings className="w-4 h-4 mr-2" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={handleLogout}
                    className="cursor-pointer text-destructive hover:bg-destructive/10 focus:text-destructive"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setLocation('/login')}
                  className="gap-2 hover:bg-primary/10 hover:text-primary hover:border-primary/30"
                >
                  <LogIn className="w-4 h-4" />
                  Login
                </Button>
                <Button
                  size="sm"
                  onClick={() => setLocation('/register')}
                  className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  <UserPlus className="w-4 h-4" />
                  Sign Up
                </Button>
              </div>
            )}

            <Button
              variant="ghost"
              size="sm"
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="h-10 w-10 p-0 rounded-full shadow hover:bg-primary/10"
            >
              {theme === 'dark' ? '🌞' : '🌙'}
              <span className="sr-only">Toggle theme</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Filter Status Display */}
      {hasActiveFilters && (
        <div className="border-b border-border/40 bg-muted/20 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4">
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-sm font-medium text-muted-foreground">Active filters:</span>

              {search && (
                <Badge variant="outline" className="gap-2">
                  Search: "{search}"
                  <button
                    onClick={() => setSearch('')}
                    className="hover:bg-destructive/20 rounded-full p-0.5"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              )}

              {selectedCategory && (
                <Badge variant="outline" className="gap-2">
                  Category: {categories.find(c => c.id === selectedCategory)?.name}
                  <button
                    onClick={() => setSelectedCategory(null)}
                    className="hover:bg-destructive/20 rounded-full p-0.5"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              )}

              {selectedTag && (
                <Badge variant="outline" className="gap-2">
                  Tag: {selectedTag}
                  <button
                    onClick={clearTagFilter}
                    className="hover:bg-destructive/20 rounded-full p-0.5"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              )}

              <Button
                variant="ghost"
                size="sm"
                onClick={clearAllFilters}
                className="text-xs h-8 px-3"
              >
                Clear All
              </Button>

              <span className="text-xs text-muted-foreground ml-auto">
                {filteredBlogs.length} of {blogs.length} posts
              </span>
            </div>
          </div>
        </div>
      )}
      <div className="w-full flex items-center justify-center py-4">
        <span className="relative px-8 py-2 rounded-xl font-semibold text-base bg-gradient-to-r from-blue-50 via-white to-green-50 dark:from-blue-900 dark:via-gray-900 dark:to-green-900 shadow-md border border-blue-100 dark:border-blue-900 text-blue-700 dark:text-blue-200 tracking-wide italic">
          <svg className="absolute left-2 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-400 dark:text-blue-300 opacity-70" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 20h9" /><path d="M12 4h9" /><rect x="3" y="8" width="13" height="8" rx="1" /></svg>
          Empowering <span className="text-orange-500 dark:text-orange-400 font-bold">Developers</span>. <span className="text-green-600 dark:text-green-400 font-bold">Sharing Knowledge</span>.
          <svg className="absolute right-2 top-1/2 -translate-y-1/2 w-5 h-5 text-green-400 dark:text-green-300 opacity-70" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" /></svg>
        </span>
      </div>
      {/* Main Content */}
      <main className="container mx-auto px-4 py-2 grid grid-cols-1 lg:grid-cols-12 gap-16">
        {/* Left Sidebar: Categories */}
        <aside className="lg:col-span-2 space-y-8">
          <div className="sticky top-24 space-y-8">
            <Card className="shadow-xl bg-white dark:bg-background border border-border">
              <CardHeader>
                <CardTitle className="text-lg font-bold text-gradient bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
                  Categories
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {/* "All Categories" option */}
                  <Badge
                    variant={selectedCategory === null ? "default" : "secondary"}
                    className={`rounded-full px-3 py-1 font-semibold cursor-pointer transition-colors duration-200 ${selectedCategory === null
                        ? 'bg-primary text-white'
                        : 'bg-primary/10 text-primary hover:bg-primary/20'
                      }`}
                    onClick={() => setSelectedCategory(null)}
                  >
                    All Categories ({blogs.length})
                  </Badge>

                  {isCategoriesLoading ? (
                    <span className="text-muted-foreground text-sm">Loading...</span>
                  ) : categoriesError ? (
                    <span className="text-red-500 text-sm">Failed to load categories</span>
                  ) : categories.length === 0 ? (
                    <span className="text-muted-foreground text-sm">No categories</span>
                  ) : (
                    categories.map((cat) => {
                      const postsCount = blogs.filter(blog => blog.category?.id === cat.id).length;
                      return (
                        <Badge
                          key={cat.id}
                          variant={selectedCategory === cat.id ? "default" : "secondary"}
                          className={`rounded-full px-3 py-1 font-semibold cursor-pointer transition-colors duration-200 ${selectedCategory === cat.id
                              ? 'bg-primary text-white'
                              : 'bg-primary/10 text-primary hover:bg-primary/20'
                            }`}
                          onClick={() => setSelectedCategory(cat.id)}
                        >
                          {cat.name} ({postsCount})
                        </Badge>
                      );
                    })
                  )}
                </div>
              </CardContent>
            </Card>
            {/* Top Featured Posts Block */}
            <Card className="shadow-xl bg-white dark:bg-background border border-border">
              <CardHeader>
                <CardTitle className="text-lg font-bold text-gradient bg-gradient-to-r from-yellow-500 to-orange-500 bg-clip-text text-transparent">
                  Top Featured Posts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="divide-y divide-border">
                  {blogs
                    .filter((post) => post.featured)
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .slice(0, 5)
                    .map((post) => (
                      <li key={post.id} className="py-2 first:pt-0 last:pb-0">
                        <a
                          href={`/blog/${post.id}`}
                          className="block text-black dark:text-white font-semibold text-base leading-tight hover:text-yellow-600 hover:underline"
                        >
                          {post.title}
                        </a>
                        {post.reading_time && (
                          <span className="block text-xs text-muted-foreground mt-1">{post.reading_time} min read</span>
                        )}
                      </li>
                    ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </aside>

        {/* Center: Blog List */}
        <section className="lg:col-span-8 mx-auto flex flex-col items-center justify-center">
          {isLoading ? (
            <div className="text-center py-12 animate-pulse text-lg text-muted-foreground">Loading blogs...</div>
          ) : error ? (
            <div className="text-center py-12 text-red-500">Failed to load blogs</div>
          ) : filteredBlogs.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-lg font-semibold text-muted-foreground mb-2">
                {selectedCategory !== null || search !== '' || selectedTag !== null
                  ? 'No blogs match your filters'
                  : 'No blogs found'
                }
              </div>
              {(selectedCategory !== null || search !== '' || selectedTag !== null) && (
                <div className="text-sm text-muted-foreground mb-4">
                  Try adjusting your search, category, or tag filter
                </div>
              )}
              {(selectedCategory !== null || search !== '' || selectedTag !== null) && (
                <Button
                  variant="outline"
                  onClick={() => {
                    setSelectedCategory(null);
                    setSelectedTag(null);
                    setSearch('');
                  }}
                  className="mt-2"
                >
                  Clear All Filters
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-6 w-full">
              {filteredBlogs.map((blog, i) => (
                <Card
                  key={blog.id}
                  className={
                    `blog-card-animate flex flex-row overflow-hidden shadow-lg bg-white dark:bg-background border border-border transition-all duration-300 rounded-lg hover:shadow-xl`
                  }
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <CardContent className="flex flex-col justify-between p-8 flex-1">
                    <div>
                      <a
                        href={`/blog/${blog.id}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 text-2xl font-bold mb-2 text-primary drop-shadow-lg hover:underline cursor-pointer"
                      >
                        {blog.title}
                      </a>

                      {/* Category Badge */}
                      {blog.category && (
                        <div className="mb-2">
                          <Badge
                            variant="secondary"
                            className="text-xs rounded-full px-3 py-1 bg-purple-100 text-purple-700 border border-purple-200 font-semibold cursor-pointer hover:bg-purple-200"
                            onClick={() => setSelectedCategory(blog.category!.id)}
                          >
                            📂 {blog.category.name}
                          </Badge>
                        </div>
                      )}

                      <p className="text-muted-foreground mb-4 line-clamp-2 text-lg">{blog.excerpt}</p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {blog.tags?.map((tag) => (
                          <Badge
                            key={tag.id}
                            variant="secondary"
                            className="text-xs rounded-full px-3 py-1 bg-primary text-white font-semibold border border-primary cursor-pointer hover:bg-primary/80 transition-colors"
                            onClick={() => setSelectedTag(tag.name.toLowerCase())}
                          >
                            #{tag.name}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center gap-3 text-sm text-muted-foreground">
                        <User className="w-5 h-5" />
                        <span className="font-medium">{blog.author?.name}</span>
                        <Calendar className="w-5 h-5 ml-4" />
                        <span>{new Date(blog.date).toLocaleDateString()}</span>
                        {blog.reading_time && (
                          <span className="flex items-center ml-4">
                            <Clock className="w-4 h-4 mr-1 text-primary" />
                            {blog.reading_time} min read
                          </span>
                        )}
                        <span className="flex items-center ml-4">
                          <Eye className="w-4 h-4 mr-1 text-primary" />
                          {Math.floor(Math.random() * 900 + 100)} views
                        </span>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(`/blog/${blog.id}`, '_blank')}
                        className={
                          `ml-auto rounded-full shadow transition-colors duration-200 border-primary text-primary hover:bg-primary/10 ` +
                          `focus:outline-none focus:ring-2 focus:ring-primary/40`
                        }
                      >
                        <ExternalLink className="w-4 h-4 mr-1" />
                        Read More
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </section>

        {/* Right Sidebar: Recent Posts */}
        <aside className="lg:col-span-2 space-y-8">
          <div className="sticky top-24 space-y-8">
            {/* Advertisement Block */}
            <Card className="shadow-lg bg-gradient-to-br from-yellow-100 via-pink-100 to-purple-100 dark:from-gray-800 dark:via-gray-900 dark:to-gray-800 border border-dashed border-yellow-400 dark:border-yellow-600 animate-pulse">
              <CardHeader>
                <CardTitle className="text-base font-bold text-yellow-700 dark:text-yellow-300">Advertisement</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center justify-center py-4">
                  <span className="text-sm text-yellow-800 dark:text-yellow-200 font-semibold mb-2">Your Ad Here</span>
                  <div className="w-40 h-20 bg-yellow-200 dark:bg-yellow-900 rounded-lg flex items-center justify-center text-yellow-600 dark:text-yellow-300 text-xs font-medium border border-yellow-300 dark:border-yellow-700">
                    300 x 100
                  </div>
                  <span className="mt-2 text-xs text-muted-foreground">Contact us to advertise</span>
                </div>
              </CardContent>
            </Card>
            {/* Recent Posts Block */}
            <Card className="shadow-xl bg-white dark:bg-background border border-border">
              <CardHeader>
                <CardTitle className="text-lg font-bold text-gradient bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
                  Recent Posts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="divide-y divide-border">
                  {blogs
                    .slice()
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .slice(0, 5)
                    .map((post) => (
                      <li key={post.id} className="py-2 first:pt-0 last:pb-0">
                        <a
                          href={`/blog/${post.id}`}
                          className="block text-black dark:text-white font-semibold text-base leading-tight hover:text-primary hover:underline"
                        >
                          {post.title}
                        </a>
                        {post.reading_time && (
                          <span className="block text-xs text-muted-foreground mt-1">{post.reading_time} min read</span>
                        )}
                      </li>
                    ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </aside>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/40 py-8 text-center text-muted-foreground bg-background/80 shadow-inner">
        <span className="text-lg font-semibold">&copy; {new Date().getFullYear()} Blog Home. All rights reserved.</span>
      </footer>
    </div>
  );
}
