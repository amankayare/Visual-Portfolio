#!/usr/bin/env python3
"""
Migration script to add is_read and read_at columns to contact_messages table
Run this script after updating the ContactMessage model
"""

import sys
import os
from datetime import datetime

# Add the current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import app
from models import db, ContactMessage

def migrate_contact_messages():
    """Add is_read and read_at columns to existing contact messages"""
    
    with app.app_context():
        try:
            # Check if columns already exist
            inspector = db.inspect(db.engine)
            columns = [col['name'] for col in inspector.get_columns('contact_messages')]
            
            if 'is_read' in columns and 'read_at' in columns:
                print("✅ Migration already completed. Columns 'is_read' and 'read_at' already exist.")
                return True
                
            print("🚀 Starting migration: Adding is_read and read_at columns to contact_messages...")
            
            # Create the new columns using raw SQL
            with db.engine.connect() as connection:
                # Add is_read column with default False
                try:
                    connection.execute(db.text(
                        "ALTER TABLE contact_messages ADD COLUMN is_read BOOLEAN DEFAULT FALSE NOT NULL"
                    ))
                    print("✅ Added 'is_read' column")
                except Exception as e:
                    if "already exists" not in str(e).lower():
                        raise e
                    print("⚠️  'is_read' column already exists")
                
                # Add read_at column
                try:
                    connection.execute(db.text(
                        "ALTER TABLE contact_messages ADD COLUMN read_at DATETIME"
                    ))
                    print("✅ Added 'read_at' column")
                except Exception as e:
                    if "already exists" not in str(e).lower():
                        raise e
                    print("⚠️  'read_at' column already exists")
                
                # Commit the schema changes
                connection.commit()
            
            # Update existing records to have is_read = False (already default)
            existing_count = ContactMessage.query.count()
            print(f"📊 Found {existing_count} existing contact messages")
            
            if existing_count > 0:
                # All existing messages will have is_read = False by default
                # and read_at = NULL, which is exactly what we want
                print("✅ Existing messages set as unread (default behavior)")
            
            print("🎉 Migration completed successfully!")
            print("\n📋 Summary:")
            print(f"   - Added 'is_read' column (BOOLEAN, default: FALSE)")
            print(f"   - Added 'read_at' column (DATETIME, nullable)")
            print(f"   - {existing_count} existing messages marked as unread")
            
            return True
            
        except Exception as e:
            print(f"❌ Migration failed: {str(e)}")
            return False

def verify_migration():
    """Verify that the migration was successful"""
    
    with app.app_context():
        try:
            # Test querying with new columns
            total_messages = ContactMessage.query.count()
            unread_messages = ContactMessage.query.filter_by(is_read=False).count()
            read_messages = ContactMessage.query.filter_by(is_read=True).count()
            
            print("\n🔍 Migration Verification:")
            print(f"   - Total messages: {total_messages}")
            print(f"   - Unread messages: {unread_messages}")
            print(f"   - Read messages: {read_messages}")
            
            # Test the to_dict method
            if total_messages > 0:
                sample_message = ContactMessage.query.first()
                message_dict = sample_message.to_dict()
                
                if 'is_read' in message_dict and 'read_at' in message_dict:
                    print("✅ to_dict() method working correctly with new fields")
                    return True
                else:
                    print("❌ to_dict() method missing new fields")
                    return False
            else:
                print("ℹ️  No messages to test, but schema looks good")
                return True
                
        except Exception as e:
            print(f"❌ Verification failed: {str(e)}")
            return False

if __name__ == "__main__":
    print("🔄 Contact Messages Migration Script")
    print("=" * 50)
    
    # Run migration
    if migrate_contact_messages():
        # Verify migration
        if verify_migration():
            print("\n🎉 Migration and verification completed successfully!")
            print("👉 You can now use the is_read and read_at fields in your application.")
        else:
            print("\n⚠️  Migration completed but verification failed. Please check manually.")
    else:
        print("\n❌ Migration failed. Please fix the errors and try again.")
