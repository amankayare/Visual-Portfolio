"""
Test script for the new change password endpoint
Usage: Run this after starting the Flask server
"""

import requests
import json

# Test the change password endpoint
def test_change_password():
    base_url = "http://localhost:5000/api"
    
    # First, you'll need to get a valid JWT token
    # This is just a test structure - you'll need actual credentials
    
    print("🧪 Testing Change Password Endpoint")
    print("=====================================")
    
    # Test data
    test_data = {
        "current_password": "old_password",
        "new_password": "new_password123"
    }
    
    # You'll need to replace this with a real JWT token
    token = "your_jwt_token_here"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.put(
            f"{base_url}/auth/change-password", 
            json=test_data,
            headers=headers
        )
        
        print(f"Status Code: {response.status_code}")
        print(f"Response: {response.json()}")
        
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    print("Manual test required - add your JWT token and credentials")
    # test_change_password()
