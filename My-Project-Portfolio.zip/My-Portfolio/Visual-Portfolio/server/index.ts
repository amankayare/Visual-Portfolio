import { createServer } from 'vite';
import path from 'path';

async function startDevServer() {
  // Create Vite server with API proxy configuration
  const vite = await createServer({
    root: path.resolve(process.cwd(), 'client'),
    server: {
      port: 3000,
      proxy: {
        '/api': {
          target: 'http://localhost:5000',
          changeOrigin: true,
          rewrite: (path) => path, // Keep the /api prefix
        }
      }
    },
    build: {
      outDir: path.resolve(process.cwd(), 'dist/public'),
    },
  });
  
  await vite.listen();
  
  console.log(`🚀 Development server running on http://localhost:3000`);
  console.log(`📱 Make sure Flask backend is running on http://localhost:5000`);
  console.log(`🔄 Proxying /api/* requests to Flask backend`);
}

if (process.env.NODE_ENV === 'development') {
  startDevServer().catch(console.error);
} else {
  console.log('Production mode - use npm run build and npm start');
}
